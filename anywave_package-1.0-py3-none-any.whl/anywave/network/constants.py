"""
"""

SIZE_INT = 4

# States for tcp connections
STATUS_SUCCESS = 0
STATUS_FAILED  = 1